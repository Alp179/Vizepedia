import Heading from "../ui/Heading";
import Row from "../ui/Row";

function DocumentDetails() {
  return (
    <Row type="horizontal">
      <Heading as="h1">All DoccumentDetails</Heading>
      <p>TEST</p>
    </Row>
  );
}

export default DocumentDetails;
