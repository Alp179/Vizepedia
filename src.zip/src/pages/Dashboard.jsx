import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Heading from "../ui/Heading";
import Row from "../ui/Row";
import StepIndicator from "../ui/StepIndicator";
import styled from "styled-components";
import "flag-icons/css/flag-icons.min.css"; // CSS importu
import { getCurrentUser } from "../services/apiAuth";

const FlagContainer = styled.div`
  position: absolute;
  top: 80%;
  right: -10%;
  transform: translateX(50%) translateY(-100%) rotate(31deg);
  width: 35vw;
  height: 20vw;
  z-index: 1000;
  overflow: hidden;
  border-radius: 10%;

  @media (max-width: 1300px) {
    top: 60%;
  }

  @media (max-width: 1250px) {
    top: 50%;
  }

  @media (max-width: 1150px) {
    top: 30%;
  }

  @media (max-width: 768px) {
    width: 50vw;
    height: 30vw;
    transform: translateX(20%) translateY(-50%) rotate(31deg);
  }

  @media (max-width: 480px) {
    width: 60vw;
    height: 40vw;
    transform: translateX(10%) translateY(-50%) rotate(31deg);
  }

  & > span {
    width: 100%;
    height: 100%;
    display: block;
    background-size: cover;
    background-position: center;
  }
`;

function Dashboard() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [countryCode, setCountryCode] = useState("");

  useEffect(() => {
    if (id) {
      localStorage.setItem("lastApplicationId", id);
    } else {
      const lastApplicationId = localStorage.getItem("lastApplicationId");
      if (lastApplicationId) {
        navigate(`/dashboard/${lastApplicationId}`);
      }
    }

    getCurrentUser().then((user) => {
      if (user && user.country) {
        setCountryCode(user.country);
      }
    });
  }, [id, navigate]);

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        gap: "50px",
      }}
    >
      <Row type="horizontal">
        <Heading as="h1">Dashboard</Heading>
      </Row>
      <StepIndicator applicationId={id} />
      {countryCode && (
        <FlagContainer>
          <span className={`fi fi-${countryCode.toLowerCase()}`}></span>
        </FlagContainer>
      )}
    </div>
  );
}

export default Dashboard;
