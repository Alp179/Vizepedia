/* eslint-disable react/prop-types */
import styled from "styled-components";
import { useCountries } from "./useCountries";

import Spinner from "../../ui/Spinner";

/// Stil tanımlamaları
const StyledSelect = styled.select`
  padding: 8px 12px;
  border-radius: 4px;
  border: 1px solid #ccc;
  margin: 10px 0;
  width: 100%;
`;

const RadioLabel = styled.label`
  display: flex;
  align-items: center;
  margin-bottom: 5px;
  cursor: pointer;

  input[type="radio"] {
    margin-right: 10px;
  }
`;

const Container = styled.div`
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  background-color: #fff;
`;

function CountrySelection({ selectedCountry, onCountryChange }) {
  const { isLoading, schCounData, mainCounData } = useCountries();

  // Event handler güncellemesi
  const handleChange = (e) => {
    onCountryChange(e.target.value);
  };

  if (isLoading) {
    return <Spinner />;
  }

  return (
    <Container>
      <StyledSelect value={selectedCountry} onChange={handleChange}>
        <option value="">Schengen Ülkeleri</option>
        {schCounData.map((country) => (
          <option key={country.id} value={country.schCountryNames}>
            {country.schCountryNames}
          </option>
        ))}
      </StyledSelect>

      {mainCounData.map((country) => (
        <RadioLabel key={country.id}>
          <input
            type="radio"
            name={country.mainCountryNames}
            value={country.mainCountryNames}
            checked={selectedCountry === country.mainCountryNames}
            onChange={handleChange}
          />
          {country.mainCountryNames}
        </RadioLabel>
      ))}
    </Container>
  );
}

export default CountrySelection;
